// Name: Spencer Banasik
// NetID: SMB200007

package MyImplementations;

public interface MyStack<T> {
    public void push(T element);
    public T pop();
    public int size();
}